#coding:utf-8

import pandas as pd
import numpy as np

def getsomething():
    s = pd.Series([1, 3, 5, np.nan, 6, 8])
    print("This is a build testzhuangshiqi")
    print(s)

getsomething()